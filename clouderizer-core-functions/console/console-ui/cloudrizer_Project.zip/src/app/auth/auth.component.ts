import { NgModule } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { SignupComponent } from './signup/signup.component';
import { LoginComponent } from './login/login.component';
import { MaterialModule } from '../material-modules';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import {MatSelectModule} from '@angular/material/select';
@Component({
  selector: 'app-auth',
  templateUrl: './auth.component.html',
  styleUrls: ['./auth.component.scss']
})

@NgModule({
  declarations: [
    SignupComponent,
    LoginComponent,
  ],
  exports: [ 
    SignupComponent,
    LoginComponent
  ],
  imports:[MaterialModule , MatFormFieldModule , MatInputModule , MatSelectModule]
})

export class AuthComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
