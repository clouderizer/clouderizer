import { Component, OnInit } from '@angular/core';
export interface Education {
  value: string;
  viewValue: string;
}


@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})


export class SignupComponent implements OnInit {
  educations: Education[] = [
    {value: 'Education1', viewValue: 'Education1'},
    {value: 'Education2', viewValue: 'Education2'},
    {value: 'Education3', viewValue: 'Education3'}
  ];

   
  constructor() { }

  ngOnInit() {
  }

}
