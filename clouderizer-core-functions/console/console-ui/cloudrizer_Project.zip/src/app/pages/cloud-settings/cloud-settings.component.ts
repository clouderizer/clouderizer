import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cloud-settings',
  templateUrl: './cloud-settings.component.html',
  styleUrls: ['./cloud-settings.component.scss']
})
export class CloudSettingsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
