import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.scss']
})
export class SettingsComponent implements OnInit {
  displayedColumns = ['projectname', 'status', 'timer', 'packages'];
  dataSource = ELEMENT_DATA;
  constructor() { }

  ngOnInit() {
  }

}
export interface PeriodicElement {
  status: string;
  projectname: number;
  timer: number;
  packages: string;
}
const ELEMENT_DATA: PeriodicElement[] = [
  {projectname: 1, status: 'Hydrogen', timer: 1.0079, packages: 'H'},
  {projectname: 2, status: 'Helium', timer: 4.0026, packages: 'He'},
  {projectname: 3, status: 'Lithium', timer: 6.941, packages: 'Li'},
  {projectname: 4, status: 'Beryllium', timer: 9.0122, packages: 'Be'},
  {projectname: 5, status: 'Boron', timer: 10.811, packages: 'B'},
  {projectname: 6, status: 'Carbon', timer: 12.0107, packages: 'C'},
  {projectname: 7, status: 'Nitrogen', timer: 14.0067, packages: 'N'},
  {projectname: 8, status: 'Oxygen', timer: 15.9994, packages: 'O'},
  {projectname: 9, status: 'Fluorine', timer: 18.9984, packages: 'F'},
  {projectname: 10, status: 'Neon', timer: 20.1797, packages: 'Ne'},
];
