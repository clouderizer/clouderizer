import { Component, OnInit, NgModule } from '@angular/core';
import {MatStepperModule} from '@angular/material/stepper';

@Component({
  selector: 'app-pages',
  templateUrl: './pages.component.html',
  styleUrls: ['./pages.component.scss']
})

@NgModule({ 
  imports:[MatStepperModule]
})

export class PagesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
