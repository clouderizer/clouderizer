import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectplatformComponent } from './selectplatform.component';

describe('SelectplatformComponent', () => {
  let component: SelectplatformComponent;
  let fixture: ComponentFixture<SelectplatformComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelectplatformComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectplatformComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
