import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listview',
  templateUrl: './listview.component.html',
  styleUrls: ['./listview.component.scss']
})
export class ListviewComponent implements OnInit {
  displayedColumns = ['icon','projectname', 'status', 'timer', 'packages','installing','description','codeEditor','startStop','buttons'];
  dataSource = ELEMENT_DATA;

  constructor() { }

  ngOnInit() {
  }

}
export interface PeriodicElement {
  projectname: string;
  packages: string;
  startStop: String;
  installing: string;
}
const ELEMENT_DATA: PeriodicElement[] = [
  {projectname: 'syedAmeen_Pro', packages: 'xyz downloading', installing:'60', startStop:"play"},
  {projectname: 'Munna',  packages: 'xyz downloading',installing:'60', startStop:"play"},
  {projectname: 'Prakash', packages: 'xyz downloading',installing:'50', startStop:"stop"},
  {projectname: 'Himanshu',  packages: 'xyz downloading',installing:'30', startStop:"play"},
  {projectname: 'Rohan',   packages: 'xyz downloading',installing:'10', startStop:"stop"},
  {projectname: 'syedAmeen_Pro', packages: 'xyz downloading',installing:'80', startStop:"play"},
  {projectname: 'Munna',  packages: 'xyz downloading',installing:'95', startStop:"stop"},
  {projectname: 'Prakash', packages: 'xyz downloading',installing:'76', startStop:"play"},
  {projectname: 'Himanshu',  packages: 'xyz downloading',installing:'55', startStop:"stop"},
  {projectname: 'Rohan',  packages: 'xyz downloading',installing:'98', startStop:"play"},
];