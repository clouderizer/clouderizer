import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-users',
  templateUrl: './manage-users.component.html',
  styleUrls: ['./manage-users.component.scss']
})
export class ManageUsersComponent implements OnInit {
  displayedColumns = ['slno','projectname', 'email', 'type', 'delete' , 'enable'];
  dataSource = ELEMENT_DATA;
  constructor() { }

  ngOnInit() {
  }

}
export interface PeriodicElement {
  slno: number,
  email: string;
  projectname: string;
  type: string;
}
const ELEMENT_DATA: PeriodicElement[] = [
  {slno: 1, projectname: 'Sayedameen', email: 'test@gmail.com', type: 'Accont Owner'},
  {slno: 2, projectname: 'demo-project', email: 'test@gmail.com', type: 'Accont Owner'},
  {slno: 3, projectname: 'demo-project1', email: 'test@gmail.com', type: 'Accont Owner'},
  {slno: 4, projectname: 'demo-project21', email: 'test@gmail.com', type: 'Accont Owner'},
  {slno: 5, projectname: 'demo-project31', email: 'test@gmail.com', type: 'Accont Owner'},
  {slno: 6, projectname: 'demo-project41', email: 'test@gmail.com', type: 'Accont Owner'},
  {slno: 7, projectname: 'demo-project51', email: 'test@gmail.com', type: 'Accont Owner'},
  {slno: 8, projectname: 'demo-project61', email: 'test@gmail.com', type: 'Accont Owner'},
  {slno: 9, projectname: 'demo-project71', email: 'test@gmail.com', type: 'Accont Owner'},
  {slno: 10,projectname: 'demo-project1', email: 'test@gmail.com', type: 'Accont Owner'},
];

