import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AuthRoutingModule } from './auth/auth-routing.module';
import { MaterialModule } from './material-modules';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { AuthModule } from './auth/auth.module';
import { PagesComponent } from './pages/pages.component';
import { SelectplatformComponent } from './pages/selectplatform/selectplatform.component';
import { NavbarComponent } from './pages/navbar/navbar.component';
import { LeftSidebarComponent } from './pages/left-sidebar/left-sidebar.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { SettingsComponent } from './pages/settings/settings.component';
import { GridviewComponent } from './pages/gridview/gridview.component';
import { ListviewComponent } from './pages/listview/listview.component';
import { ProfileSettingsComponent } from './pages/profile-settings/profile-settings.component';
import { ManageUsersComponent } from './pages/manage-users/manage-users.component';
import { CloudSettingsComponent } from './pages/cloud-settings/cloud-settings.component';
import { BillingComponent } from './pages/billing/billing.component';
import { SubscriptionComponent } from './pages/subscription/subscription.component';
import { NewProjectComponent } from './pages/new-project/new-project.component';

@NgModule({
  declarations: [
    AppComponent,
    PagesComponent,
    SelectplatformComponent,
    NavbarComponent,
    LeftSidebarComponent,
    DashboardComponent,
    SettingsComponent,
    GridviewComponent,
    ListviewComponent,
    ProfileSettingsComponent,
    ManageUsersComponent,
    CloudSettingsComponent,
    BillingComponent,
    SubscriptionComponent,
    NewProjectComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    AuthRoutingModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    AuthModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
